DYNASTY: MEDIEVAL WORLD — Android проект (версия 3.9)

Это ИСХОДНЫЙ ПРОЕКТ, не готовый APK.

Как собрать APK на ноутбуке:
1. Установите Android Studio.
2. Распакуйте архив и откройте папку DynastyMedievalWorld_Android_Project в Android Studio.
3. Дождитесь загрузки Gradle и Android SDK (потребуется интернет).
4. Выберите Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Установите полученный app-debug.apk на Android.

Игра работает офлайн, HTML лежит в app/src/main/assets/index.html.
Сохранения localStorage будут отдельными от браузерной версии. Не удаляйте приложение, если хотите сохранить прогресс.
Для публикации в Google Play потребуется отдельная подготовка, тестирование и подписанный AAB.
